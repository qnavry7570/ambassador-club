import { T } from './ui';

export default function Footer(){
  return <footer style={{background:"#060606",padding:"80px 48px 40px"}}>
    <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",gap:64,maxWidth:1200,margin:"0 auto"}}>
      <div>
        <div style={{fontFamily:T.sans,fontSize:12,fontWeight:700,letterSpacing:"0.25em",color:T.gold,marginBottom:12}}>AMBASSADOR CLUB</div>
        <div style={{fontFamily:T.serif,fontSize:15,fontStyle:"italic",color:T.dim,marginBottom:20}}>Where Poland's Finest Meet</div>
        <div style={{fontFamily:T.sans,fontSize:11,color:T.dim,letterSpacing:"0.1em"}}>BEST OF POLAND</div>
      </div>
      <div>
        <div style={{fontFamily:T.sans,fontSize:11,fontWeight:700,letterSpacing:"0.15em",color:T.ivory,textTransform:"uppercase",marginBottom:24}}>Klub</div>
        {[{l:"O nas",h:"/about"},{l:"Filary",h:"/sport"},{l:"Journal",h:"/journal"},{l:"Kontakt",h:"/contact"}].map((x,i)=><a key={i} href={x.h} style={{display:"block",fontFamily:T.sans,fontSize:13,color:T.muted,textDecoration:"none",marginBottom:12,fontWeight:300}}>{x.l}</a>)}
      </div>
      <div>
        <div style={{fontFamily:T.sans,fontSize:11,fontWeight:700,letterSpacing:"0.15em",color:T.ivory,textTransform:"uppercase",marginBottom:24}}>Członkostwo</div>
        {[{l:"Korzyści",h:"/membership"},{l:"Proces aplikacyjny",h:"/membership"},{l:"Wydarzenia",h:"/events"},{l:"Members Area",h:"/login"}].map((x,i)=><a key={i} href={x.h} style={{display:"block",fontFamily:T.sans,fontSize:13,color:T.muted,textDecoration:"none",marginBottom:12,fontWeight:300}}>{x.l}</a>)}
      </div>
      <div>
        <div style={{fontFamily:T.sans,fontSize:11,fontWeight:700,letterSpacing:"0.15em",color:T.ivory,textTransform:"uppercase",marginBottom:24}}>Kontakt</div>
        <div style={{fontFamily:T.sans,fontSize:13,color:T.muted,fontWeight:300,lineHeight:2}}>ul. Foksal 3/5<br/>00-366 Warszawa<br/><span style={{color:T.gold}}>concierge@ambassadorclub.pl</span></div>
      </div>
    </div>
    <div style={{marginTop:64,paddingTop:24,borderTop:"1px solid rgba(201,169,97,0.06)",textAlign:"center"}}>
      <span style={{fontFamily:T.sans,fontSize:11,color:T.ghost}}>© 2026 Ambassador Club · Best of Poland. Wszelkie prawa zastrzeżone.</span>
    </div>
  </footer>;
}
